﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjektZaliczeniowy
{
    public class PlytaSpecjalna : Plyta
    {
        public string Dodatki { get; set; }
        public bool LimitowanaEdycja { get; set; }

        public PlytaSpecjalna(string tytul, string rodzaj, string dlugosc, string artysta, string kod, string opisSpecjalny, bool limitowanaEdycja)
            : base(tytul, rodzaj, dlugosc, artysta, kod)
        {
            Dodatki = opisSpecjalny;
            LimitowanaEdycja = limitowanaEdycja;
        }

        public override string ToString()
        {
            return base.ToString() + $"\nOpis Specjalny: {Dodatki}\nLimitowana Edycja: {(LimitowanaEdycja ? "Tak" : "Nie")}";
        }
    }
}
