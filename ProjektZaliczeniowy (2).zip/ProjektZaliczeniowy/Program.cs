﻿using ProjektZaliczeniowy;
using System;
using System.IO;
using System.Collections.Generic;
using static ProjektZaliczeniowy.Plyta;

public class Aplikacja
{
    private static List<Plyta> plytyLista = new List<Plyta>();

    public static void Main(string[] args)
    {
        int opcja;
        do
        {
            opcja = WyswietlMenu();
            WykonajAkcje(opcja);
        } while (opcja != 6);
    }

    private static int WyswietlMenu()
    {
        Console.WriteLine("Baza Plyt");
        Console.WriteLine("1. Dodaj Plyte");
        Console.WriteLine("2. Wyswietl Wszystkie Plyty");
        Console.WriteLine("3. Szczegoly Wybranej Plyty");
        Console.WriteLine("4. Zapisz Baze do Pliku");
        Console.WriteLine("5. Odczytaj Baze z Pliku");
        Console.WriteLine("6. Wyjdz");
        Console.Write("Wybierz opcje: ");
        if (int.TryParse(Console.ReadLine(), out int opcja))
        {
            return opcja;
        }
        else
        {
            return 0;
        }
    }

    private static void WykonajAkcje(int opcja)
    {
        switch (opcja)
        {
            case 1:
                DodajPlyte();
                break;
            case 2:
                WyswietlWszystkiePlyty();
                break;
            case 3:
                SzczegolyWybranejPlyty();
                break;
            case 4:
                ZapiszBazeDoPliku("Baza.txt");
                break;
            case 5:
                OdczytajBazeZPliku();
                break;
            case 6:
                Console.WriteLine("Zamykanie programu...");
                break;
            default:
                Console.WriteLine("Nieprawidlowa opcja.");
                break;
        }
    }

    private static void DodajPlyte()
    {
        Console.Clear();
        Console.Write("Podaj nazwe plyty: ");
        string tytul = Console.ReadLine();

        Console.Write("Podaj rodzaj plyty: ");
        string rodzaj = Console.ReadLine();

        Console.Write("Podaj dlugosc plyty: ");
        string dlugosc = Console.ReadLine();

        Console.Write("Podaj wykonawcow: ");
        string artysta = Console.ReadLine();

        Console.Write("Podaj identyfikator: ");
        string kod = Console.ReadLine();

        Console.Write("Czy jest to specjalna edycja? (tak/nie): ");
        string odpowiedzSpecjalna = Console.ReadLine().ToLower();

        Plyta nowaPlyta;
        if (odpowiedzSpecjalna == "tak")
        {
            Console.Write("Podaj opis specjalny: ");
            string opisSpecjalny = Console.ReadLine();

            Console.Write("Czy to limitowana edycja? (tak/nie): ");
            string odpowiedzLimitowana = Console.ReadLine().ToLower();
            bool limitowanaEdycja = odpowiedzLimitowana == "tak";

            nowaPlyta = new PlytaSpecjalna(tytul, rodzaj, dlugosc, artysta, kod, opisSpecjalny, limitowanaEdycja);
        }
        else
        {
            nowaPlyta = new Plyta(tytul, rodzaj, dlugosc, artysta, kod);
        }

        while (true)
        {
            Console.Write("Czy chcesz dodac utwor do plyty? (tak/nie): ");
            string odpowiedz = Console.ReadLine().ToLower();

            if (odpowiedz == "nie")
                break;

            Console.Write("Podaj nazwe utworu: ");
            string tytulUtworu = Console.ReadLine();

            Console.Write("Podaj dlugosc utworu: ");
            string dlugoscUtworu = Console.ReadLine();

            Console.Write("Podaj wykonawcow utworu: ");
            string artystaUtworu = Console.ReadLine();

            Console.Write("Podaj kompozytora utworu: ");
            string kompozytorUtworu = Console.ReadLine();

            Console.Write("Podaj numer utworu: ");
            string numerUtworu = Console.ReadLine();

            Utwor nowyUtwor = new Utwor(tytulUtworu, dlugoscUtworu, artystaUtworu, kompozytorUtworu, numerUtworu);
            nowaPlyta.DolaczUtwor(nowyUtwor);
        }

        plytyLista.Add(nowaPlyta);
        Console.WriteLine("Plyta zostala dodana.");
    }

    private static void SzczegolyWybranejPlyty()
    {
        Console.Clear();
        Console.WriteLine("Lista Plyt:");

        for (int i = 0; i < plytyLista.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {plytyLista[i].Tytul}");
        }

        Console.Write("Wybierz numer plyty: ");
        if (int.TryParse(Console.ReadLine(), out int numerPlyty) && numerPlyty > 0 && numerPlyty <= plytyLista.Count)
        {
            var wybranaPlyta = plytyLista[numerPlyty - 1];
            Console.Clear();
            Console.WriteLine($"Plyta: {wybranaPlyta.Tytul}");
            Console.WriteLine($"Rodzaj: {wybranaPlyta.Rodzaj}");
            Console.WriteLine($"Dlugosc: {wybranaPlyta.Dlugosc}");
            Console.WriteLine($"Artysta: {wybranaPlyta.Artysta}");
            Console.WriteLine($"Kod: {wybranaPlyta.Kod}");
            if (wybranaPlyta is PlytaSpecjalna specjalna)
            {
                Console.WriteLine($"Opis Specjalny: {specjalna.Dodatki}");
                Console.WriteLine($"Limitowana Edycja: {(specjalna.LimitowanaEdycja ? "Tak" : "Nie")}");
            }
            Console.WriteLine("Utwory:");
            foreach (var utwor in wybranaPlyta.UtworyLista)
            {
                Console.WriteLine(utwor.ToString());
            }
        }
        else
        {
            Console.WriteLine("Nieprawidlowy numer plyty.");
        }

        Console.WriteLine("Nacisnij dowolny klawisz aby powrocic do menu...");
        Console.ReadKey();
    }

    private static void WyswietlWszystkiePlyty()
    {
        Console.Clear();
        Console.WriteLine("Lista Plyt:");
        for (int i = 0; i < plytyLista.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {plytyLista[i].Tytul}");
        }
        Console.WriteLine("\n");
    }

    private static void ZapiszBazeDoPliku(string nazwaPliku)
    {
        string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, nazwaPliku);

        if (File.Exists(path))
        {
            File.Delete(path);
        }

        using (var writer = new StreamWriter(path))
        {
            foreach (var plyta in plytyLista)
            {
                writer.WriteLine($"{plyta.Tytul},{plyta.Rodzaj},{plyta.Dlugosc},{plyta.Artysta},{plyta.Kod}");
                if (plyta is PlytaSpecjalna specjalna)
                {
                    writer.WriteLine($"  Specjalna,{specjalna.Dodatki},{specjalna.LimitowanaEdycja}");
                }
                foreach (var utwor in plyta.UtworyLista)
                {
                    writer.WriteLine($"  {utwor.NumerUtworu},{utwor.Tytul},{utwor.CzasTrwania},{utwor.Artysta},{utwor.Kompozytor}");
                }
            }
        }

        Console.WriteLine("Baza zapisana do pliku.");
    }

    private static void OdczytajBazeZPliku()
    {
        Console.Clear();
        string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Baza.txt");

        if (!File.Exists(path))
        {
            Console.WriteLine("Plik nie istnieje.");
            return;
        }

        using (var reader = new StreamReader(path))
        {
            string line;
            Plyta plyta = null;

            while ((line = reader.ReadLine()) != null)
            {
                if (!line.StartsWith("  "))
                {
                    var plytaInfo = line.Split(',');
                    if (plytaInfo.Length == 5)
                    {
                        plyta = new Plyta(plytaInfo[0], plytaInfo[1], plytaInfo[2], plytaInfo[3], plytaInfo[4]);
                    }
                    else if (plytaInfo.Length == 8 && plytaInfo[5] == "Specjalna")
                    {
                        plyta = new PlytaSpecjalna(plytaInfo[0], plytaInfo[1], plytaInfo[2], plytaInfo[3], plytaInfo[4], plytaInfo[6], bool.Parse(plytaInfo[7]));
                    }
                    if (plyta != null)
                    {
                        plytyLista.Add(plyta);
                    }
                }
                else if (plyta != null)
                {
                    var utworInfo = line.Trim().Split(',');
                    Utwor utwor = new Utwor(utworInfo[1], utworInfo[2], utworInfo[3], utworInfo[4], utworInfo[0]);
                    plyta.DolaczUtwor(utwor);
                }
            }
        }
    }
}
