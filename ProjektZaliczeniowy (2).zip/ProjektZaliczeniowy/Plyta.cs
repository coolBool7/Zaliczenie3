﻿using System;
using System.Collections.Generic;

namespace ProjektZaliczeniowy
{
    public class Plyta
    {
        public string Tytul { get; set; }
        public string Rodzaj { get; set; }
        public string Dlugosc { get; set; }
        public string Artysta { get; set; }
        public string Kod { get; set; }
        public List<Utwor> UtworyLista { get; set; }

        public Plyta(string tytul, string rodzaj, string dlugosc, string artysta, string kod)
        {
            Tytul = tytul;
            Rodzaj = rodzaj;
            Dlugosc = dlugosc;
            Artysta = artysta;
            Kod = kod;
            UtworyLista = new List<Utwor>();
        }

        public void DolaczUtwor(Utwor utwor)
        {
            UtworyLista.Add(utwor);
        }

        public override string ToString()
        {
            return $"{Tytul} ({Rodzaj}) - Artysta: {Artysta}, Kod: {Kod}";
        }
    }

    public struct Utwor
    {
        public string Tytul { get; set; }
        public string CzasTrwania { get; set; }
        public string Artysta { get; set; }
        public string Kompozytor { get; set; }
        public string NumerUtworu { get; set; }

        public Utwor(string tytul, string czasTrwania, string artysta, string kompozytor, string numerUtworu)
        {
            Tytul = tytul;
            CzasTrwania = czasTrwania;
            Artysta = artysta;
            Kompozytor = kompozytor;
            NumerUtworu = numerUtworu;
        }

        public override string ToString()
        {
            return $"{NumerUtworu}. {Tytul} ({CzasTrwania}) - Artysta: {Artysta}, Kompozytor: {Kompozytor}";
        }
    }
}
